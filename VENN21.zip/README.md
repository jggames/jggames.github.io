VennDiagram
===========

A program that draws Venn logic diagrams.  Also has a quiz function to test your skills.
